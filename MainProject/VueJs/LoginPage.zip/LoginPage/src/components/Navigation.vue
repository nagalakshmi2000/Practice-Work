<template>
  <nav class="navbar navbar-expand-lg navbar-light bg-primary">
    <a class="navbar-brand text-light" href="#">Navbar</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
      aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item active">
          <!-- <a class="nav-link" href="#">Home</a> -->
          <router-link to="/" class="nav-link text-light"> Home</router-link>
        </li>
        <li class="nav-item active">
          <!-- <a class="nav-link" href="#">Home</a> -->
          <router-link to="/categories" class="nav-link text-light"> Categories</router-link>
        </li>
        <li class="nav-item active">
          <!-- <a class="nav-link" href="#">Home</a> -->
          <router-link to="/posts/add" class="nav-link text-light"> AddPost</router-link>
        </li>
        <li class="nav-item" v-if="!isLoggedIn">
          <!-- <a class="nav-link" href="#">Registration</a> -->
          <router-link to="/registration" class="nav-link text-light"> Registration</router-link>
        </li>
        <li class="nav-item" v-if="!isLoggedIn">
          <!-- <a class="nav-link" href="#">Login</a> -->
          <router-link to="/login" class="nav-link text-light"> Login</router-link>
        </li>
        <li class="nav-item" v-if="isLoggedIn">
          <a href="/" @click.prevent="onLogout()" class="nav-link text-light"> LogOut</a>
        </li>
      </ul>
    </div>
  </nav>
</template>

<script>
import emitter from 'tiny-emitter/instance';
import { isUserAuthenticated } from '../services/LocalStorage';
import { removeDetailsFromLocalStorage } from '../services/LocalStorage';
export default {
  data() {
    return {
      isLoggedIn: false
    }
  },
  mounted() {
    this.isLoggedIn = isUserAuthenticated();

    emitter.on('logged-in-event', (status) => {
      this.isLoggedIn = status;
    }
    )

  },
  methods: {
    onLogout() {
      removeDetailsFromLocalStorage();
      this.isLoggedIn = false;
      emitter.emit('success-message-event', 'user is successfully logged out');
      this.$router.push('/login');
    }
  }

}
</script>

<style lang="scss" scoped>

</style>