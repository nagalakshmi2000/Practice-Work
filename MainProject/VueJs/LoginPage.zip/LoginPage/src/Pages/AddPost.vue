<template>
  <h1>Add Posts</h1>
  <div>
    <form>
      <div class="my-3 col-md-12" >
        <label>Title</label>
        <input type="text" class="form-control" v-model="title"/>
      </div>
      <div class="my-3 col-md-12" >
        <label>Select Category</label>
        <select class="form-control" v-model="categoryId">
          <option>Select Category</option>
          <option :value="category.id" v-for="category in categoriesArray" :key="category.id">{{category.name}}</option>
        </select>
      </div>
      <div class="my-3 col-md-6" >
        <button class="btn btn-primary">AddPost</button>
      </div>
    </form>
  </div>
</template>
<script>
import axios from 'axios';

export default{
  data() {
    return {
      title:'',
      categoryId:'',
      categoriesArray:[]
    }
  },
  mounted() {
    axios.get(`https://vue-posts-af023-default-rtdb.firebaseio.com/categories.json`).then((response) =>{
      let categoriesData = response.data;
      for(let key in categoriesData)
      this.categoriesArray.push({ ...categoriesData[key], id:key})


    })
  }
}
</script>