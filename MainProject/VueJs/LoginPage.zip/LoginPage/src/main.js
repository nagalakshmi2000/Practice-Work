import { createApp } from 'vue'
import App from './App.vue'
import Home from "./Pages/Home.vue";
import Login from "./Pages/Login.vue";
import Registration from "./Pages/Registration.vue";
import Categories from "./Pages/Categories.vue";
import AddCategories from "./Pages/AddCategories.vue";
import AddPost from "./Pages/AddPost.vue";
import { createRouter, createWebHashHistory } from 'vue-router'
const routes = [
  {
    path: "/",
    component: Home
  },
  {
    path: "/login",
    component: Login
  },
  {
    path: "/registration",
    component: Registration
  },
  {
    path:'/categories',
    component: Categories
  },
  {
    path:'/categories/add',
    component:AddCategories
  },
  {
    path:'/posts/add',
    component:AddPost
  }
]

const app = createApp(App);
const router = createRouter({
  history: createWebHashHistory(),
  routes: routes,
})
app.use(router)
app.mount('#app')
